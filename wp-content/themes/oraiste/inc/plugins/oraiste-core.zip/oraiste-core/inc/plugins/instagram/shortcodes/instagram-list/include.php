<?php

include_once ORAISTE_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-oraistecore-instagram-list-shortcode.php';
