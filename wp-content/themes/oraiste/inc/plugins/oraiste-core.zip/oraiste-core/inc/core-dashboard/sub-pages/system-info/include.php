<?php

include_once ORAISTE_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-oraistecore-dashboard-system-info-page.php';
