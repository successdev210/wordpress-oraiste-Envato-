<?php

include_once ORAISTE_CORE_PLUGINS_PATH . '/contact-form-7/class-oraistecore-contact-form-7.php';
