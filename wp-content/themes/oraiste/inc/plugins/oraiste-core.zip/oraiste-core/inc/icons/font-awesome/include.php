<?php

include_once ORAISTE_CORE_INC_PATH . '/icons/font-awesome/class-oraistecore-font-awesome-pack.php';
