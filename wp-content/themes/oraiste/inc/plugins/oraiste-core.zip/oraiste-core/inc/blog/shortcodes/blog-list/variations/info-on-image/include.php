<?php

include_once ORAISTE_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/info-on-image/info-on-image.php';
