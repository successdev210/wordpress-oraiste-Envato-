<?php

include_once ORAISTE_CORE_INC_PATH . '/icons/elegant-icons/class-oraistecore-elegant-icons-pack.php';
