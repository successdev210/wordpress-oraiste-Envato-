<?php

include_once ORAISTE_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-oraistecore-woocommerce-dropdown-cart-widget.php';
