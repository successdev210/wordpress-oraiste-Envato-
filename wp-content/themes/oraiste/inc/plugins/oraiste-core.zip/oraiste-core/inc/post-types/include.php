<?php

include_once ORAISTE_CORE_CPT_PATH . '/class-oraistecore-custom-post-types.php';
