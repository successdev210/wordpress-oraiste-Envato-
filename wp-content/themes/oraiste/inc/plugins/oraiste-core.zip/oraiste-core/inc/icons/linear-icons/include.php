<?php

include_once ORAISTE_CORE_INC_PATH . '/icons/linear-icons/class-oraistecore-linear-icons-pack.php';
