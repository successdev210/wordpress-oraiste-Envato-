<?php

include_once ORAISTE_CORE_INC_PATH . '/icons/simple-line-icons/class-oraistecore-simple-line-icons-pack.php';
