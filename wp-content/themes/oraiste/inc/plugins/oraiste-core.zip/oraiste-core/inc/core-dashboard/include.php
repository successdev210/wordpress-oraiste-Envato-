<?php

include_once ORAISTE_CORE_INC_PATH . '/core-dashboard/class-oraistecore-dashboard.php';
