<?php

echo qode_framework_wp_kses_html( 'img', $logo_dark_image );
echo qode_framework_wp_kses_html( 'img', $logo_light_image );
