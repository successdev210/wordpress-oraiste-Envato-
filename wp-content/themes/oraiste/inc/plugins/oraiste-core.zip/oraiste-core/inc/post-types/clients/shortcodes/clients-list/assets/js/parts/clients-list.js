(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.oraiste_core_clients_list             = {};
	qodefCore.shortcodes.oraiste_core_clients_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );
