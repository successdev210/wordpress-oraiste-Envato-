<?php

include_once ORAISTE_CORE_INC_PATH . '/header/helper.php';
include_once ORAISTE_CORE_INC_PATH . '/header/class-oraistecore-header.php';
include_once ORAISTE_CORE_INC_PATH . '/header/class-oraistecore-headers.php';
include_once ORAISTE_CORE_INC_PATH . '/header/template-functions.php';
