<?php

include_once ORAISTE_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-oraistecore-twitter-list-shortcode.php';
