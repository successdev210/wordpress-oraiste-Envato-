<?php

include_once ORAISTE_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/helper.php';
include_once ORAISTE_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/class-oraistecore-woocommerce-yith-wishlist.php';
