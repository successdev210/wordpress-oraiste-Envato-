<?php

include_once ORAISTE_CORE_INC_PATH . '/icons/material-icons/class-oraistecore-material-icons-pack.php';
