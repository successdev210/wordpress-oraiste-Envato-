<?php

include_once ORAISTE_CORE_INC_PATH . '/icons/linea-icons/class-oraistecore-linea-icons-pack.php';
