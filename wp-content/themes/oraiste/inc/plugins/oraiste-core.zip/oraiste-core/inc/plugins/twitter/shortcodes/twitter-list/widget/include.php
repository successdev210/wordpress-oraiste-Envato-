<?php

include_once ORAISTE_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/class-oraistecore-twitter-list-widget.php';
