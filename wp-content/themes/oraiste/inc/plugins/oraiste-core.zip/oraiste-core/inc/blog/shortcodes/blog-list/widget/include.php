<?php

include_once ORAISTE_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-oraistecore-blog-list-widget.php';
