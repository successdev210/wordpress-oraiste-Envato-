<?php

include_once ORAISTE_CORE_INC_PATH . '/core-dashboard/sub-pages/import/class-oraistecore-dashboard-import-page.php';
include_once ORAISTE_CORE_INC_PATH . '/core-dashboard/sub-pages/import/class-oraistecore-dashboard-import.php';
