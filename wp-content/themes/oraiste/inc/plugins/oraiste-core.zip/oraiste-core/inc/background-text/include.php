<?php

include_once ORAISTE_CORE_INC_PATH . '/background-text/helper.php';
