<?php
//
// if ( ! function_exists( 'oraiste_core_add_blog_list_variation_simple' ) ) {
// 	/**
// 	 * Function that add variation layout for this module
// 	 *
// 	 * @param array $variations
// 	 *
// 	 * @return array
// 	 */
// 	function oraiste_core_add_blog_list_variation_simple( $variations ) {
// 		$variations['simple'] = esc_html__( 'Simple', 'oraiste-core' );
//
// 		return $variations;
// 	}
//
// 	add_filter( 'oraiste_core_filter_blog_list_layouts', 'oraiste_core_add_blog_list_variation_simple' );
// }
