<div class="qodef-m-order-details">
	<div class="qodef-m-order-label"><?php esc_html_e( 'Subtotal:', 'oraiste-core' ); ?></div>
	<div class="qodef-m-order-amount"><?php wc_cart_totals_subtotal_html(); ?></div>
</div>
