<?php

include_once ORAISTE_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-oraistecore-instagram-list-widget.php';
