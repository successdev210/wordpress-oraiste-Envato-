<?php

include_once ORAISTE_CORE_CPT_PATH . '/portfolio/shortcodes/horizontal-portfolio-showcase/class-oraistecore-horizontal-portfolio-showcase-shortcode.php';
