<?php

include_once ORAISTE_CORE_PLUGINS_PATH . '/instagram/helper.php';
