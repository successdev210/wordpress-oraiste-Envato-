<?php

include_once ORAISTE_CORE_PLUGINS_PATH . '/woocommerce/class-oraistecore-woocommerce.php';
