<?php

include_once ORAISTE_CORE_INC_PATH . '/opener-icon/helper.php';
