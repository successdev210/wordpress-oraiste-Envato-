<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once ORAISTE_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once ORAISTE_CORE_PLUGINS_PATH . '/elementor/class-oraistecore-elementor-section-handler.php';
}
