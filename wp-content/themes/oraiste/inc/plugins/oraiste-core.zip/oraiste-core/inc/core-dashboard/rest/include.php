<?php

include_once ORAISTE_CORE_INC_PATH . '/core-dashboard/rest/class-oraistecore-dashboard-rest-api.php';
