<?php
// Include logo
oraiste_core_get_header_logo_image();
?>
<!--<div class="qodef-header-holder--right">-->
	<?php
	// Include widget area one
	oraiste_core_get_header_widget_area();

	// Include main navigation
	oraiste_core_template_part( 'header', 'layouts/switch/templates/navigation' );

	?>
<!--</div>-->
