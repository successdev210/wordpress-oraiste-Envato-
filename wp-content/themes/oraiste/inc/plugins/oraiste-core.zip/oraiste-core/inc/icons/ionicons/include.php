<?php

include_once ORAISTE_CORE_INC_PATH . '/icons/ionicons/class-oraistecore-ionicons-pack.php';
